//
//  ViewController.swift
//  Dicee
//
//  Created by Priscilla Ikhena on 13/01/2021.
//

import UIKit
import SceneKit
import ARKit


class ViewController: UIViewController, ARSCNViewDelegate {
    
    var videoArray = [SCNNode]() //array of all video nodes
    var anchorArray = [ARImageAnchor]() //array of all ARImageAnchors
    var readButtonCube = String()
    
  
    
    @IBOutlet var UIView: UIView!
    @IBOutlet weak var sceneView: ARSCNView!
    @IBOutlet weak var instructionLabel: UILabel!
    @IBOutlet weak var readButtonOutlet: UIButton!
    @IBOutlet weak var cancelButtonOutlet: UIButton!
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        sceneView.delegate = self
        sceneView.autoenablesDefaultLighting = true
        
        //creatingBordersAndUIForButtons
        readButtonOutlet.layer.borderWidth = 1.0 / UIScreen.main.nativeScale
        readButtonOutlet.layer.borderColor = UIColor.white.cgColor
        readButtonOutlet.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        
        cancelButtonOutlet.layer.borderWidth = 1.0 / UIScreen.main.nativeScale
        cancelButtonOutlet.layer.borderColor = UIColor.white.cgColor
        cancelButtonOutlet.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            //Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
        configuration.detectionImages = referenceImages
        
            //Run the view's session
        sceneView.session.run(configuration)
  
        
            //Hide all buttons initially
        hideButtons()
     
        
        }
    
    

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        //Pause the view's session
        sceneView.session.pause()
    }
    
    //In this function, the image gets detected, and then the function that launches the video gets called.
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {

         //Checks that we have detected an ARImageAnchor
        guard let imageAnchor = anchor as? ARImageAnchor else { return }
        anchorArray.append(imageAnchor)
        let referenceImage = imageAnchor.referenceImage
        let referenceImageName = String(referenceImage.name!)
        
       
        //Creates a video player node for each detected target
        
        let videoNode = launchVideo(referenceImage, referenceImageName)
        videoArray.append(videoNode)
        node.addChildNode(videoNode)
      //  sceneView.session.remove(anchor: imageAnchor)
        
        //after video has been overlayed, we want to display the buttons for the user to interact with.
        DispatchQueue.main.async {
               self.instructionLabel.isHidden = true
        }
       
        showButtons()
       }
    
    
    
    //the Cancel button clears out all videos and all anchors, so that the session can repeatedly launch videos without having to quit the app.
    
    @IBAction func cancelButton(_ sender: Any) {
        //the
        
        if !videoArray.isEmpty {
            for videoNode in videoArray {
                videoNode.removeFromParentNode()
            }
        }
        
        if !anchorArray.isEmpty {
            for anchor in anchorArray {
                sceneView.session.remove(anchor: anchor)
            }
        }
        
       hideButtons()
        DispatchQueue.main.async {
               self.instructionLabel.isHidden = false
        }
        
        
    }
    
    
    //if Read/Cubestory is pressed, we want to overlay the video with information about the memory cube.
    
    
    
    @IBAction func readButton(_ sender: Any) {
        if (readButtonCube == "teddybear1") {
            print("teddybear one does...")
        }
        
        else if (readButtonCube == "teddybear2") {
            print("teddybear two does...")
        }
        
        else if (readButtonCube == "teddybear3") {
            print("teddybear three does...")
        }
        
        else if (readButtonCube == "teddybear4") {
            print("teddybear four does...")
        }
        
        else if (readButtonCube == "teddybear5") {
            print("teddybear five does...")
        }
        
        else if (readButtonCube == "teddybear6") {
            print("teddybear six does...")
        }
    }
    
    // this function launches/overlays the video for a given memory cube image
    
   
    func launchVideo(_ target: ARReferenceImage, _ targetName: String) -> SCNNode{
        let plane = SCNPlane(width: target.physicalSize.width, height: target.physicalSize.height)
        let planeNode = SCNNode(geometry: plane)
        if (targetName == "teddybear1"){
            readButtonCube = "teddybear1"
            plane.firstMaterial?.diffuse.contents = UIColor.blue
            planeNode.opacity = 1
            planeNode.eulerAngles.x = -Float.pi / 2
            
        }
        
        else if (targetName == "teddybear2"){
            readButtonCube = "teddybear2"
            plane.firstMaterial?.diffuse.contents = UIColor.yellow
            planeNode.opacity = 1
            planeNode.eulerAngles.x = -Float.pi / 2
        }
        
        else if (targetName == "teddybear3"){
            readButtonCube = "teddybear3"
            plane.firstMaterial?.diffuse.contents = UIColor.red
            planeNode.opacity = 1
            planeNode.eulerAngles.x = -Float.pi / 2
        }
        
        else if (targetName == "teddybear4"){
            readButtonCube = "teddybear4"
            plane.firstMaterial?.diffuse.contents = UIColor.green
            planeNode.opacity = 1
            planeNode.eulerAngles.x = -Float.pi / 2
        }
        
        else if (targetName == "teddybear5"){
            readButtonCube = "teddybear5"
            plane.firstMaterial?.diffuse.contents = UIColor.purple
            planeNode.opacity = 1
            planeNode.eulerAngles.x = -Float.pi / 2
        }
        
        
        return planeNode
        
       
    
    }
    

    func showButtons() {

        DispatchQueue.main.async {
            self.cancelButtonOutlet.isHidden = false
            self.readButtonOutlet.isHidden = false
            
        }

    }
//
    func hideButtons(){
        DispatchQueue.main.async {
            self.cancelButtonOutlet.isHidden = true
            self.readButtonOutlet.isHidden = true
           
        }
    }
        
    }




