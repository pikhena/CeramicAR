//
//  ViewController.swift
//  Dicee
//
//  Created by Priscilla Ikhena on 13/01/2021.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {
    
    var videoArray = [SCNNode]() //array of all video nodes
    var anchorArray = [ARImageAnchor]() //array of all ARImageAnchors
  
    
    @IBOutlet var UIView: UIView!
    @IBOutlet weak var sceneView: ARSCNView!
    @IBOutlet weak var instructionLabel: UILabel!
    @IBOutlet weak var pauseButtonOutlet: UIButton!
    @IBOutlet weak var readButtonOutlet: UIButton!
    @IBOutlet weak var cancelButtonOutlet: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        sceneView.delegate = self
        //sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        sceneView.autoenablesDefaultLighting = true
     
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            //Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
        configuration.detectionImages = referenceImages
        
            //Run the view's session
        sceneView.session.run(configuration)
  
        
            //Hide all buttons initially
        hideButtons()
       print("in view will appear")
        
        }
    
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        //Pause the view's session
        sceneView.session.pause()
    }
    

    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {

         //Check that we have Detected An ARImageAnchor
        guard let imageAnchor = anchor as? ARImageAnchor else { return }
        anchorArray.append(imageAnchor)
        let referenceImage = imageAnchor.referenceImage
       
        //Create A Video Player Node For Each Detected Target
        //node.addChildNode(createdVideoPlayerNodeFor(validAnchor.referenceImage))
        let videoNode = launchVideo(referenceImage)
        videoArray.append(videoNode)
        node.addChildNode(videoNode)
      //  sceneView.session.remove(anchor: imageAnchor)
        
        //after video has been overlayed, we want to display the buttons for the user to interact with.
        DispatchQueue.main.async {
               self.instructionLabel.isHidden = true
        }
       
        showButtons()
       }
    
    
    
    //the Cancel button clears out all videos and all anchors, so that the session can repeatedly launch videos without having to quit the app.
    
    @IBAction func cancelButton(_ sender: Any) {
        //the
        
        if !videoArray.isEmpty {
            for videoNode in videoArray {
                videoNode.removeFromParentNode()
            }
        }
        
        if !anchorArray.isEmpty {
            for anchor in anchorArray {
                sceneView.session.remove(anchor: anchor)
            }
        }
        
    }
    
    
    //if Read is pressed, we want to overlay the video with information about the memory cube. If it is pressed again
    //we want to cancel the information overlayed.
    
    //if pause is pressed, we want to pause the video? Maybe add this to functionality to next version.
    
    @IBAction func readButton(_ sender: Any) {
        
    }
    
    
    @IBAction func pauseButton(_ sender: Any) {
        
    }
    
    
   
    func launchVideo(_ target: ARReferenceImage) -> SCNNode{
  
        let plane = SCNPlane(width: target.physicalSize.width, height: target.physicalSize.height)
        plane.firstMaterial?.diffuse.contents = UIColor.blue
        let planeNode = SCNNode(geometry: plane)
        planeNode.opacity = 1
        planeNode.eulerAngles.x = -Float.pi / 2
        return planeNode
        
       
    
    }
    

    func showButtons() {

        DispatchQueue.main.async {
            self.cancelButtonOutlet.isHidden = false
            self.readButtonOutlet.isHidden = false
            self.pauseButtonOutlet.isHidden = false
        }

    }
//
    func hideButtons(){
        DispatchQueue.main.async {
            self.cancelButtonOutlet.isHidden = true
            self.readButtonOutlet.isHidden = true
            self.pauseButtonOutlet.isHidden = true
        }
    }
        
    }




